//
//  fail.swift
//  Pool Party
//
//  Created by JD Smith on 2/24/21.
//

import Foundation
import SpriteKit

class fail: SKScene {
    var bg = SKSpriteNode()
    var play = 1
    override func didMove(to view: SKView) {
        playfail()
        bg = self.childNode(withName: "bg") as! SKSpriteNode
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let main = GameScene(fileNamed: "GameScene")
        main?.scaleMode = .aspectFill
        self.view?.presentScene(main!, transition: SKTransition.fade(withDuration: 0.5))
    }
    func playfail(){
        if play == 1{
            bg.run(SKAction.playSoundFileNamed("fail", waitForCompletion: false))
            play = 2
        }
    }
    override func update(_ currentTime: TimeInterval) {
    }
}
