//
//  GameScene.swift
//  Pool Party
//
//  Created by JD Smith on 2/19/21.
//
//
//  title screen.swift
//  Pool Party
//
//  Created by JD Smith on 3/2/21.
//

import SpriteKit
import GameplayKit
import ObjectiveC
class GameScene: SKScene {
    var woodLife = 4
    var level = 1
    var tople = UserDefaults().integer(forKey: "level")
    var startx = 0
    var starty = -381
    var max_rot = 9
    var min_rot = -9
    var rot = 0
    var BallsLeft = 3
    var mode = 1
    var diy = 0
    var dix = 0
    var bally = CGFloat()
    var ballx = CGFloat()
    var life1 = 1.0
    var life2 = 1.0
    var life3 = 2.0
    var life4 = 2.0
    var life5 = 2.0
    var life6 = 2.0
    var play = 1
    var bd = false
    var bd2 = false
    var bd3 = false
    var bd4 = false
    var ball = SKSpriteNode()
    var ball1 = SKSpriteNode()
    var ball2 = SKSpriteNode()
    var ball3 = SKSpriteNode()
    var ball4 = SKSpriteNode()
    var ball5 = SKSpriteNode()
    var ball6 = SKSpriteNode()
    var arrow = SKSpriteNode()
    var supply = SKLabelNode()
    var right = SKSpriteNode()
    var lift = SKSpriteNode()
    var go = SKSpriteNode()
    var reset = SKSpriteNode()
    var metal1 = SKSpriteNode()
    var metal2 = SKSpriteNode()
    var metal3 = SKSpriteNode()
    var thorn1 = SKSpriteNode()
    var thorn2 = SKSpriteNode()
    var thorn3 = SKSpriteNode()
    var thorn4 = SKSpriteNode()
    var thorn5 = SKSpriteNode()
    var thorn6 = SKSpriteNode()
    var thorn7 = SKSpriteNode()
    var thorn8 = SKSpriteNode()
    var thorn9 = SKSpriteNode()
    var thorn10 = SKSpriteNode()
    var thorn11 = SKSpriteNode()
    var thorn12 = SKSpriteNode()
    var thorn13 = SKSpriteNode()
    var wood1 = SKSpriteNode()
    var nowood = SKSpriteNode()
    var fire_bottle = SKSpriteNode()
    var fire = SKSpriteNode()
    var intro = SKSpriteNode()
    let error = SKAction.playSoundFileNamed("error.mp3", waitForCompletion: true)
    let thump = SKAction.playSoundFileNamed("thump.mp3", waitForCompletion: true)
    var touchLocation = CGPoint()
    var hasGone = false
    override func didMove(to view: SKView) {
        mode = 0
        play = 0
        level = tople
        playpool()
        ball = self.childNode(withName: "ball") as! SKSpriteNode
        ball1 = self.childNode(withName: "ball-1") as! SKSpriteNode
        ball2 = self.childNode(withName: "ball-2") as! SKSpriteNode
        ball3 = self.childNode(withName: "ball-3") as! SKSpriteNode
        ball4 = self.childNode(withName: "ball-4") as! SKSpriteNode
        ball5 = self.childNode(withName: "ball-5") as! SKSpriteNode
        ball6 = self.childNode(withName: "ball-6") as! SKSpriteNode
        arrow = self.childNode(withName: "arrow") as! SKSpriteNode
        right = self.childNode(withName: "right") as! SKSpriteNode
        lift = self.childNode(withName: "lift") as! SKSpriteNode
        go = self.childNode(withName: "go") as! SKSpriteNode
        metal1 = self.childNode(withName: "metal-1") as! SKSpriteNode
        metal2 = self.childNode(withName: "metal-2") as! SKSpriteNode
        metal3 = self.childNode(withName: "metal-3") as! SKSpriteNode
        thorn1 = self.childNode(withName: "thorn-1") as! SKSpriteNode
        thorn2 = self.childNode(withName: "thorn-2") as! SKSpriteNode
        thorn3 = self.childNode(withName: "thorn-3") as! SKSpriteNode
        thorn4 = self.childNode(withName: "thorn-4") as! SKSpriteNode
        thorn5 = self.childNode(withName: "thorn-5") as! SKSpriteNode
        thorn6 = self.childNode(withName: "thorn-6") as! SKSpriteNode
        thorn7 = self.childNode(withName: "thorn-7") as! SKSpriteNode
        thorn8 = self.childNode(withName: "thorn-8") as! SKSpriteNode
        thorn9 = self.childNode(withName: "thorn-9") as! SKSpriteNode
        thorn10 = self.childNode(withName: "thorn-10") as! SKSpriteNode
        thorn11 = self.childNode(withName: "thorn-11") as! SKSpriteNode
        thorn12 = self.childNode(withName: "thorn-12") as! SKSpriteNode
        thorn13 = self.childNode(withName: "thorn-13") as! SKSpriteNode
        wood1 = self.childNode(withName: "wood-1") as! SKSpriteNode
        reset = self.childNode(withName: "reset") as! SKSpriteNode
        supply = self.childNode(withName: "supply") as! SKLabelNode
        nowood = self.childNode(withName: "no-wood") as! SKSpriteNode
        fire_bottle = self.childNode(withName: "fire-bottle") as! SKSpriteNode
        fire = self.childNode(withName: "fire") as! SKSpriteNode
        supply.text = "\(BallsLeft)"
        if mode == 1{
            playpool()
        }
        life5 = 0
        life6 = 0
        if UserDefaults().integer(forKey: "level") == 1{
            BallsLeft = 3
            supply.text = "\(BallsLeft)"
            life5 = 0
            life6 = 0
            }
        if UserDefaults().integer(forKey: "level") == 2{
            BallsLeft = 3
            supply.text = "\(BallsLeft)"
            ball1.position.x = -262
            ball1.position.y = 0
            ball2.position.x = 0
            ball2.position.y = 0
            ball3.texture = SKTexture(imageNamed: "ball-1")
            ball3.position.x = 262
            ball3.position.y = 0
            ball4.position.x = 0
            ball4.position.y = 300
            ball4.texture = SKTexture(imageNamed: "ball-3")
            life3 = 1
            life2 = 1
            life1 = 1
            life4 = 3
            life5 = 0
            life6 = 0
            }
        if UserDefaults().integer(forKey: "level") == 3{
            BallsLeft = 2
            supply.text = "\(BallsLeft)"
            life1 = 2
            life2 = 2
            life3 = 2
            life4 = 2
            ball1.texture = SKTexture(imageNamed: "ball-2")
            ball2.texture = SKTexture(imageNamed: "ball-2")
            ball3.texture = SKTexture(imageNamed: "ball-2")
            ball4.texture = SKTexture(imageNamed: "ball-2")
            ball5.texture = SKTexture(imageNamed: "ball-2")
            ball6.texture = SKTexture(imageNamed: "ball-2")
            ball1.position.x = -162
            ball2.position.x = -262
            ball3.position.x = -162
            ball1.position.y = 200
            ball2.position.y = 0
            ball3.position.y = -200
            ball4.position.x = 162
            ball5.position.x = 262
            ball6.position.x = 162
            ball4.position.y = 200
            ball5.position.y = 0
            ball6.position.y = -200
            life5 = 2
            life6 = 2
        }
        if UserDefaults().integer(forKey: "level") == 4{
            life2 = 1
            life4 = 2
            life3 = 0
            life1 = 0
            life5 = 0
            life6 = 0
            ball3.position.x = 10000
            ball1.position.x = 10000
            metal1.position.x = -252
            metal2.position.x = 252
            metal1.position.y = 60
            metal2.position.y = 370
            supply.text = "\(BallsLeft)"
        }
        if UserDefaults().integer(forKey: "level") == 5{
            BallsLeft = 2
            supply.text = "\(BallsLeft)"
            life1 = 1
            life2 = 1
            life3 = 1
            life4 = 1
            ball3.texture = SKTexture(imageNamed: "ball-1")
            ball4.texture = SKTexture(imageNamed: "ball-1")
            metal1.position.x = -260
            metal1.position.y = 0
            metal2.zRotation = 1.5708
            metal2.position.x = 0
            metal2.position.y = 300
            ball1.position.x = -255
            ball2.position.x = -255
            ball3.position.x = 25
            ball4.position.x = 262
            ball1.position.y = 200
            ball2.position.y = 500
            ball3.position.y = 600
            ball4.position.y = 200
        }
        if UserDefaults().integer(forKey: "level") == 6{
            BallsLeft = 4
            life4 = 4
            supply.text = "\(BallsLeft)"
            life1 = 0
            life2 = 0
            life3 = 0
            life5 = 0
            life6 = 0
            ball4.texture = SKTexture(imageNamed: "ball-4")
            ball4.position.x = 0
            ball4.position.y = 200
            metal1.position.x = -38
            metal2.position.x = 162
            metal3.position.x = -238
            metal1.position.y = -42
            metal2.position.y = 258
            metal3.position.y = 258
            metal2.zRotation = 1.5708
            metal3.zRotation = 1.5708
            ball1.position.x += 200000
            ball2.position.x += 200000
            ball3.position.x += 200000
        }
        if UserDefaults().integer(forKey: "level") == 7{
            BallsLeft = 3
            supply.text = "\(BallsLeft)"
            life1 = 0
            life2 = 3
            life3 = 3
            life4 = 3
            ball1.position.x = -16200
            ball2.texture = SKTexture(imageNamed: "ball-3")
            ball3.texture = SKTexture(imageNamed: "ball-3")
            ball4.texture = SKTexture(imageNamed: "ball-3")
            ball2.position.x = 0
            ball3.position.x = -162
            ball2.position.y = 0
            ball3.position.y = 0
            ball4.position.x = 162
            ball4.position.y = 0
            life5 = 0
            life6 = 0
        }
        if UserDefaults().integer(forKey: "level") == 8{
            BallsLeft = 5
            supply.text = "\(BallsLeft)"
            life1 = 1
            life2 = 2
            life3 = 0
            life4 = 0
            life5 = 0
            life6 = 0
            ball1.position.x = -262
            ball2.position.x = 262
            ball1.position.y = 550
            ball2.position.y = 550
            metal1.position.x = -262
            metal2.position.x = 0
            metal3.position.x = 262
            metal1.position.y = 400
            metal2.position.y = 300
            metal3.position.y = 400
            ball3.position.x = 10000000
            ball4.position.x = 10000000
        }
        if UserDefaults().integer(forKey: "level") == 9{
            life1 = 0
            life2 = 0
            life5 = 0
            life6 = 0
            ball1.position.x = 100000
            ball2.position.x = 100000
            life3 = 2
            life4 = 2
            metal1.position.x = -262
            metal2.position.x = 262
            metal1.position.y = 100
            metal2.position.y = 100
            metal1.physicsBody?.pinned = true
            metal2.physicsBody?.pinned = true
            metal1.size = CGSize(width: 400, height: 100)
            metal2.size = CGSize(width: 400, height: 100)
            metal1.physicsBody?.mass = 0.0001
            metal2.physicsBody?.mass = 0.0001
            metal1.texture = SKTexture(imageNamed: "metal-attached")
            metal2.texture = SKTexture(imageNamed: "metal-attached")
        }
        if UserDefaults().integer(forKey: "level") == 10{
            life1 = 0
            life2 = 0
            life5 = 0
            life6 = 0
            ball1.position.x = 100000
            ball2.position.x = 100000
            ball3.position.x = 262
            ball3.position.y = 0
            ball4.position.x = -262
            ball4.position.y = 0
            life3 = 4
            life4 = 4
            metal1.position.x = 0
            metal1.position.y = 0
            metal1.zRotation = 1.5708
            metal1.physicsBody?.pinned = true
            metal1.physicsBody?.mass = 0.0001
            metal1.texture = SKTexture(imageNamed: "metal-attached")
            ball3.texture = SKTexture(imageNamed: "ball-4")
            ball4.texture = SKTexture(imageNamed: "ball-4")
        }
        if UserDefaults().integer(forKey: "level") == 11{
            BallsLeft = 2
            supply.text = "\(BallsLeft)"
            life1 = 0
            life2 = 1
            life5 = 0
            life6 = 0
            ball1.position.x = 100000
            ball3.position.x = 390
            ball3.position.y = 300
            ball4.position.x = -390
            ball4.position.y = 300
            life3 = 2
            life4 = 2
            ball2.position.x = 0
            ball2.position.y = 500
            thorn2.position.x = -410
            thorn2.position.y = 200
            thorn1.position.x = 410
            thorn1.position.y = 200
            ball3.texture = SKTexture(imageNamed: "ball-2")
            ball4.texture = SKTexture(imageNamed: "ball-2")
        }
        if UserDefaults().integer(forKey: "level") == 12{
            life1 = 1
            life2 = 1
            life3 = 1
            life4 = 1
            ball3.texture = SKTexture(imageNamed: "ball-1")
            ball4.texture = SKTexture(imageNamed: "ball-1")
            metal1.position.x = -175
            metal3.position.x = -175
            metal1.position.y = 400
            metal3.position.y = 142
            ball3.position.y = 500
            ball3.position.x = -262
        }
        if UserDefaults().integer(forKey: "level") == 13{
            life1 = 2
            life2 = 2
            life3 = 2
            life4 = 2
            life5 = 0
            life6 = 0
            ball2.texture = SKTexture(imageNamed: "ball-2")
            ball1.texture = SKTexture(imageNamed: "ball-2")
            thorn1.zRotation = 3.14159
            thorn2.zRotation = 3.14159
            thorn1.position.x = -230
            thorn2.position.x = 230
            thorn1.position.y = 600
            thorn2.position.y = 600
            metal1.position.x = -262
            metal2.position.x = 262
            metal1.position.y = 58
            metal2.position.y = 58
            ball1.position.x = -262
            ball2.position.x = 262
            ball3.position.x = -262
            ball4.position.x = 262
            ball1.position.y = 200
            ball2.position.y = 200
            ball3.position.y = -42
            ball4.position.y = -42
        }
        if UserDefaults().integer(forKey: "level") == 14{
            thorn2.position.x = -412
            thorn3.position.x = -412
            thorn4.position.x = -412
            thorn5.position.x = -412
            thorn6.position.x = -412
            thorn2.position.y = -340
            thorn3.position.y = -140
            thorn4.position.y = 60
            thorn5.position.y = 260
            thorn6.position.y = 460
            thorn7.position.x = -200
            thorn7.position.y = 583
            thorn8.position.x = 0
            thorn8.position.y = 583
            thorn9.position.x = 200
            thorn9.position.y = 583
            thorn10.position.x = 412
            thorn11.position.x = 412
            thorn12.position.x = 412
            thorn13.position.x = 412
            thorn1.position.x = 412
            thorn10.position.y = -340
            thorn11.position.y = -140
            thorn12.position.y = 60
            thorn13.position.y = 260
            thorn1.position.y = 460
            ball3.position.x = 262
            ball3.position.y = -42
            ball4.position.x = -262
            ball4.position.y = -42
            ball5.position.x = 0
            ball5.position.y = -42
            ball6.position.x = 262
            ball6.position.y = 200
            ball1.position.x = 0
            ball1.position.y = 200
            ball2.position.x = -262
            ball2.position.y = 200
            ball6.texture = SKTexture(imageNamed: "ball-1")
            life1 = 1
            life2 = 1
            life3 = 2
            life4 = 2
            life5 = 2
            life6 = 1
        }
        if UserDefaults().integer(forKey: "level") == 15{
            thorn7.position.x = -412
            thorn7.position.y = 583
            thorn9.position.x = 412
            thorn9.position.y = 583
            ball1.position.x = 412
            ball1.position.y = 433
            ball2.position.x = -412
            ball2.position.y = 433
            ball3.position.x = 162
            ball3.position.y = 460
            ball4.position.x = -162
            ball4.position.y = 460
            wood1.position.x = 0
            wood1.position.y = 356
        }
        if UserDefaults().integer(forKey: "level") == 16{
            BallsLeft = 2
            supply.text = "\(BallsLeft)"
            life3 = 1
            life5 = 1
            life6 = 1
            life4 = 5
            ball4.texture = SKTexture(imageNamed: "ball-5")
            ball3.texture = SKTexture(imageNamed: "ball-1")
            ball5.texture = SKTexture(imageNamed: "ball-1")
            ball6.texture = SKTexture(imageNamed: "ball-1")
            ball1.position.x = 450
            ball1.position.y = 500
            ball2.position.x = -425
            ball2.position.y = 100
            ball3.position.x = 425
            ball3.position.y = 100
            ball4.position.x = 0
            ball4.position.y = 0
            ball5.position.x = 225
            ball5.position.y = 280
            ball6.position.x = -425
            ball6.position.y = 380
        }
        if UserDefaults().integer(forKey: "level") == 17{
            BallsLeft = 2
            supply.text = "\(BallsLeft)"
            ball1.position.x = 1000
            ball2.position.x = 1000
            life1 = 0
            life2 = 0
            thorn2.position.x = 88
            thorn2.position.y = 0
            wood1.position.x = -262
            wood1.position.y = 0
            ball3.position.x = -420
            ball3.position.y = 108
            ball4.position.x = -125
            ball4.position.y = 108
        }
        if UserDefaults().integer(forKey: "level") == 18{
            ball3.texture = SKTexture(imageNamed: "ball-1")
            ball4.texture = SKTexture(imageNamed: "ball-3")
            life1 = 1
            life2 = 1
            life3 = 1
            life4 = 3
            wood1.position.x = 0
            wood1.position.y = 500
            metal1.zRotation = 1.5708
            metal2.zRotation = 1.5708
            metal1.position.x = 200
            metal2.position.x = -200
            metal1.position.y = 200
            metal2.position.y = 200
            ball1.position.x = 0
            ball1.position.y = 200
            ball2.position.x = -362
            ball2.position.y = 200
            ball3.position.x = 362
            ball3.position.y = 200
            ball4.position.x = 0
            ball4.position.y = 633
        }
        if UserDefaults().integer(forKey: "level") == 19{
            wood1.position.x = -260
            wood1.position.y = 500
            thorn2.position.x = 88
            thorn2.position.y = 583
            fire_bottle.position.x = -362
            fire_bottle.position.y = -167
            fire.position.x = -362
            fire.position.y = -72
            ball1.position.x = -325
            ball1.position.y = 633
        }
        if UserDefaults().integer(forKey: "level") == 20{
            life2 = 0
            life3 = 0
            life4 = 0
            life1 = 2
            thorn2.position.x = -412
            thorn2.position.y = 0
            thorn1.position.x = 412
            thorn1.position.y = 0
            metal1.position.x = 0
            metal1.position.y = 0
            ball1.position.x = 0
            ball1.position.y = 100
            ball2.position.x = 100000
            ball3.position.x = 100000
            ball4.position.x = 100000
            metal1.physicsBody?.pinned = true
            metal1.physicsBody?.mass = 0.0001
            ball1.texture = SKTexture(imageNamed: "ball-2")
            metal1.texture = SKTexture(imageNamed: "metal-attached")
        }
    }
    func playpool(){
        if play == 1{
            reset.run(SKAction.playSoundFileNamed("pool", waitForCompletion: false))
            play = 2
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !hasGone{
            if let touch = touches.first {
                let touchloc = touch.location(in: self)
                let touchwe = nodes(at: touchloc)
                if !touchwe.isEmpty {
                    for node in touchwe {
                        if let sprite = node as? SKSpriteNode {
                            if sprite == lift {
                                lift.run(SKAction.rotate(byAngle: 0, duration: 0))
                                ball.zRotation += 0.174533
                                arrow.zRotation += 0.174533
                                rot -= 1
                            }
                            if sprite == right {
                                lift.run(SKAction.rotate(byAngle: 0, duration: 0))
                                ball.zRotation -= 0.174533
                                arrow.zRotation -= 0.174533
                                rot += 1
                                }
                            if sprite == reset {
                                mode = 1
                                ball.position.x = CGFloat(startx)
                                ball.position.y = CGFloat(starty)
                                ball.zRotation = 0
                                arrow.zRotation = 0
                                rot = 0
                                ball.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 0))
                                ball.physicsBody?.friction = 100
                                ball.physicsBody?.isDynamic = false
                                BallsLeft -= 1
                                supply.text = "\(BallsLeft)"
                            }
                            if sprite == go {
                                if mode == 1{
                                    mode = 2
                                    ball.physicsBody?.friction = 0.2
                                    ball.physicsBody?.isDynamic = true
                                    if rot == 0{
                                        ball.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 40))
                                        dix = 0
                                        diy = 40
                                    }
                                    if rot == 1 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: 10, dy: 40))
                                        dix = 10
                                        diy = 40
                                    }
                                    if rot == 2 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: 20, dy: 40))
                                        dix = 20
                                        diy = 40
                                    }
                                    if rot == 3 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: 30, dy: 40))
                                        dix = 30
                                        diy = 40
                                    }
                                    if rot == 4 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: 40, dy: 40))
                                        dix = 40
                                        diy = 40
                                    }
                                    if rot == 5 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: 50, dy: 40))
                                        dix = 50
                                        diy = 40
                                    }
                                    if rot == 6 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: 60, dy: 40))
                                        dix = 60
                                        diy = 40
                                    }
                                    if rot == 7 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: 70, dy: 40))
                                        dix = 70
                                        diy = 40
                                    }
                                    if rot == 8 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: 80, dy: 40))
                                        dix = 80
                                        diy = 40
                                    }
                                    if rot == 9 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: 90, dy: 40))
                                        dix = 90
                                        diy = 40
                                    }
                                    if rot == -1 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: -10, dy: 40))
                                        dix = -10
                                        diy = 40
                                    }
                                    if rot == -2 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: -20, dy: 40))
                                        dix = -20
                                        diy = 40
                                    }
                                    if rot == -3 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: -30, dy: 40))
                                        dix = -30
                                        diy = 40
                                    }
                                    if rot == -4 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: -40, dy: 40))
                                        dix = -40
                                        diy = 40
                                    }
                                    if rot == -5 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: -50, dy: 40))
                                        dix = -50
                                        diy = 40
                                    }
                                    if rot == -6 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: -60, dy: 40))
                                        dix = -60
                                        diy = 40
                                    }
                                    if rot == -7 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: -70, dy: 40))
                                        dix = -70
                                        diy = 40
                                    }
                                    if rot == -8 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: -80, dy: 40))
                                        dix = -80
                                        diy = 40
                                    }
                                    if rot == -9 {
                                        ball.physicsBody?.applyImpulse(CGVector(dx: -90, dy: 40))
                                        dix = -90
                                        diy = 40
                                }
                                }
                            }
                            if rot >= max_rot || rot <= min_rot{
                                run(error)
                                if rot <= min_rot{
                                    ball.zRotation -= 0.174533
                                    arrow.zRotation -= 0.174533
                                    rot += 1
                                    }
                                if rot >= max_rot{
                                    ball.zRotation += 0.174533
                                    arrow.zRotation += 0.174533
                                    rot -= 1
                                    }
                                }
                        }
                    }
                }
            }
        }
        
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !hasGone{
            if let touch = touches.first {
                let touchloc = touch.location(in: self)
                let touchwe = nodes(at: touchloc)
                
                if !touchwe.isEmpty {
                    for node in touchwe {
                        if let sprite = node as? SKSpriteNode {
                            if sprite == ball {
                                print("shoot complete")
                                if rot == 0{
                                    ball.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 20))
                                }
                            }
                            if sprite == lift {
                                lift.run(SKAction.rotate(byAngle: 0, duration: 0))
                                ball.zRotation += 0.174533
                                arrow.zRotation += 0.174533
                                rot -= 1
                            }
                            if sprite == right {
                                lift.run(SKAction.rotate(byAngle: 0, duration: 0))
                                ball.zRotation -= 0.174533
                                arrow.zRotation -= 0.174533
                                rot += 1
                            }
                            if rot >= max_rot || rot <= min_rot{
                                run(error)
                                if rot <= min_rot{
                                    ball.zRotation -= 0.174533
                                    arrow.zRotation -= 0.174533
                                    rot += 1
                                }
                                if rot >= max_rot{
                                    ball.zRotation += 0.174533
                                    arrow.zRotation += 0.174533
                                    rot -= 1
                                }
                        }
                    }
                }
            }
        }
        
    }
    }
    override func update(_ currentTime: TimeInterval) {
        if wood1.intersects(ball) || wood1.intersects(ball1) || wood1.intersects(ball2) || wood1.intersects(ball3) || wood1.intersects(ball4) || wood1.intersects(ball5) || wood1.intersects(ball6){
            run(thump)
            print(woodLife)
        if ball.intersects(wood1){
            ball.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
            }
            if woodLife == 4{
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                    woodLife = 3
                    wood1.texture = SKTexture(imageNamed: "wood-break")
                }
            }
            if woodLife == 3{
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                    woodLife = 2
                    wood1.texture = SKTexture(imageNamed: "wood-break-2")
                }
            }
            if woodLife == 2{
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                    woodLife = 1
                    wood1.texture = SKTexture(imageNamed: "wood-break-3")
                }
            }
            if woodLife == 1{
                nowood.position.x = wood1.position.x
                nowood.position.y = wood1.position.y
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                    woodLife = 0
                    wood1.position.x += 1000000
                    
                }
            }
        }
        if ball.intersects(ball1) || ball.intersects(ball2) || ball.intersects(ball3) || ball.intersects(ball4) || ball.intersects(ball5) || ball.intersects(ball6){
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                ball.physicsBody?.applyImpulse(CGVector(dx: -dix, dy: -diy))
            }
        }
        if life1 == 0 && life2 == 0 && life3 == 0 && life4 == 0 && life5 == 0 && life6 == 0{
            print(UserDefaults().integer(forKey: "level"))
            
            if UserDefaults().integer(forKey: "level") == 2{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 3
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 3{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 4
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 4{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 5
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 5{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 6
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 6{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 7
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 7{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 8
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 8{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 9
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 9{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 10
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 10{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 11
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 11{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 12
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 12{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 13
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 13{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 14
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 14{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 15
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 15{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 16
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 16{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 17
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 17{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 18
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 18{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 19
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 19{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                level = 20
                UserDefaults.standard.set(level, forKey: "level")
                print(level)
            }
            }
            if UserDefaults().integer(forKey: "level") == 0{
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.01){ [self] in
                    level = 2
                    UserDefaults.standard.set(level, forKey: "level")
                    print(level)
                }
            }
            let Complete = complete(fileNamed: "complete")
            Complete?.scaleMode = .aspectFill
            self.view?.presentScene(Complete!, transition: SKTransition.fade(withDuration: 0.5))
            print("Stop complete")
                }

        if BallsLeft == 0{
            reset.run(SKAction.stop())
            let Fail = fail(fileNamed: "fail")
            Fail?.scaleMode = .aspectFill
            self.view?.presentScene(Fail!, transition: SKTransition.fade(withDuration: 0.5))
            mode = 3
        }
        if ball1.texture == SKTexture(imageNamed: "ball1"){
            life1 = 1
        }
        if ball2.texture == SKTexture(imageNamed: "ball1"){
            life2 = 1
        }
        if ball3.texture == SKTexture(imageNamed: "ball2"){
            life3 = 2
        }
        if ball4.texture == SKTexture(imageNamed: "ball2"){
            life4 = 2
        }
        if ball4.texture == SKTexture(imageNamed: "ball3"){
            life4 = 3
        }
        if ball1.intersects(wood1){
            ball1.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
        }
        if ball2.intersects(wood1){
            ball2.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
        }
        if ball3.intersects(wood1){
            ball3.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
        }
        if ball4.intersects(wood1){
            ball4.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
        }
        if ball5.intersects(wood1){
            ball5.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
        }
        if ball6.intersects(wood1){
            ball6.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
        }
        if ball.intersects(thorn1) || ball.intersects(thorn2) || ball.intersects(thorn3) || ball.intersects(thorn4) || ball.intersects(thorn5) || ball.intersects(thorn6) || ball.intersects(thorn7) || ball.intersects(thorn8) || ball.intersects(thorn9) || ball.intersects(thorn10) || ball.intersects(thorn11) || ball.intersects(thorn12) || ball.intersects(thorn13){
            ball.physicsBody?.isDynamic = false
        }
        if ball1.intersects(ball) || ball1.intersects(ball2) || ball1.intersects(ball3) || ball1.intersects(ball4) || ball1.intersects(ball5) || ball1.intersects(ball6){
            if life1 == 2{
                ball1.texture = SKTexture(imageNamed: "ball-1")
                ball1.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                    life1 = 1
                }
                }
            if life1 == 1{
                ball1.texture = SKTexture(imageNamed: "ball")
                ball1.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                    life1 = 0
                }
                }
            if ball1.intersects(ball2) || ball1.intersects(ball3) || ball1.intersects(ball4) {
                ball1.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
            }
        }
        if ball2.intersects(ball) || ball2.intersects(ball1) || ball2.intersects(ball3) || ball2.intersects(ball4) || ball2.intersects(ball5) || ball2.intersects(ball6){
            if life2 == 3{
                    ball2.texture = SKTexture(imageNamed: "ball-2")
                    ball2.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                        life2 = 2
                }
            }
            if life2 == 2{
                    ball2.texture = SKTexture(imageNamed: "ball-1")
                    ball2.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                        life2 = 1
                }
            }
            if life2 == 1{
                    ball2.texture = SKTexture(imageNamed: "ball")
                    ball2.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                        life2 = 0
                }
                }
            if ball2.intersects(ball1) || ball2.intersects(ball3) || ball2.intersects(ball4) {
                ball2.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
            }
            }
        if ball3.intersects(ball) || ball3.intersects(ball1) || ball3.intersects(ball2) || ball3.intersects(ball4) || ball3.intersects(ball5) || ball3.intersects(ball6) {
            if life3 == 4{
                    ball3.texture = SKTexture(imageNamed: "ball-3")
                    ball3.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                        life3 = 3
                }
                }
            if life3 == 3{
                    ball3.texture = SKTexture(imageNamed: "ball-2")
                    ball3.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                        life3 = 2
                }
                }

            if life3 == 2{
                    ball3.texture = SKTexture(imageNamed: "ball-1")
                    ball3.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                        life3 = 1
                }
                }
            if  ball3.intersects(ball1) || ball3.intersects(ball2) || ball3.intersects(ball4) {
                ball3.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
            }
            if life3 == 1{
                    ball3.texture = SKTexture(imageNamed: "ball")
                    ball3.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                        life3 = 0
                }
                }
        }
        if ball4.intersects(ball) || ball4.intersects(ball1) || ball4.intersects(ball3) || ball4.intersects(ball2) || ball4.intersects(ball5) || ball4.intersects(ball6){
            if life4 == 5{
                ball4.texture = SKTexture(imageNamed: "ball-4")
                ball4.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                    life4 = 4
                }
                }
            if life4 == 4{
                ball4.texture = SKTexture(imageNamed: "ball-3")
                ball4.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                    life4 = 3
                }
                }
            if life4 == 3{
                ball4.texture = SKTexture(imageNamed: "ball-2")
                ball4.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                    life4 = 2
                }
                }
            if life4 == 2{
                ball4.texture = SKTexture(imageNamed: "ball-1")
                ball4.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                    life4 = 1
                }
                }
            if life4 == 1{
                ball4.texture = SKTexture(imageNamed: "ball")
                ball4.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                life4 = 0
                }
                }
        if ball5.intersects(ball) || ball5.intersects(ball1) || ball5.intersects(ball2) || ball5.intersects(ball4) || ball5.intersects(ball3) || ball5.intersects(ball6) {
            if life5 == 2{
                    ball5.texture = SKTexture(imageNamed: "ball-1")
                    ball5.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                        life5 = 1
                }
                }
            if  ball5.intersects(ball1) || ball5.intersects(ball2) || ball5.intersects(ball4) || ball5.intersects(ball3) || ball5.intersects(ball6) {
                ball5.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
            }
            if life5 == 1{
                    ball5.texture = SKTexture(imageNamed: "ball")
                    ball5.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                        life5 = 0
                }
                }
            else{
                ball5.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
            }
        }
        if ball.intersects(fire_bottle){
            print("collided")
            fire.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
        }
        if fire.intersects(wood1) || fire.intersects(nowood){
            print("burnt")
            run(thump)
            fire.physicsBody?.isDynamic = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                fire.physicsBody?.isDynamic = true
            }
            fire.position.y = fire_bottle.position.y + 39
            fire.position.x = fire_bottle.position.x
            woodLife = 0
            nowood.texture = SKTexture(imageNamed: "wood-burnt")
            nowood.position = wood1.position
            wood1.position.x = 100000
        }
        if nowood.position.x == wood1.position.x{
            fire.position.x += 10000
        }
        if ball6.intersects(ball) || ball6.intersects(ball1) || ball6.intersects(ball2) || ball6.intersects(ball4) || ball6.intersects(ball5) || ball6.intersects(ball3) {
            if life6 == 2{
                    ball6.texture = SKTexture(imageNamed: "ball-1")
                    ball6.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                        life6 = 1
                }
                }
            if  ball6.intersects(ball1) || ball6.intersects(ball2) || ball6.intersects(ball4) || ball6.intersects(ball3) || ball6.intersects(ball5)  {
                ball6.physicsBody?.applyImpulse(CGVector(dx: -dix/5, dy: -diy/5))
            }
            if life6 == 1{
                    ball6.texture = SKTexture(imageNamed: "ball")
                    ball6.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1){ [self] in
                        life6 = 0
                }
                }
            else{
                ball6.physicsBody?.applyImpulse(CGVector(dx: dix, dy: diy))
            }
        }
}
        





}



